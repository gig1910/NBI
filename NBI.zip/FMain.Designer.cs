﻿
namespace NBI
{
    partial class FMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FMain));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.справочникиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.физическиеЛицаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.подразделенияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.должностиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.пользователиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.контрагентыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.документыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.календарныеПланыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.проектыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.постановкаЗадачToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.исполнениеЗадачToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отчетыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сводныйКалендарныйПланToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.анализВыполненияЗадачпланфактToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Products_Button = new System.Windows.Forms.Button();
            this.Departments_Button = new System.Windows.Forms.Button();
            this.Partners_Button = new System.Windows.Forms.Button();
            this.Positions_Button = new System.Windows.Forms.Button();
            this.Individuals_Button = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ExecutionTasks_Button = new System.Windows.Forms.Button();
            this.SettingTasks_Button = new System.Windows.Forms.Button();
            this.Projects_Button = new System.Windows.Forms.Button();
            this.CalendarProjects_Button = new System.Windows.Forms.Button();
            this.Exit_Button = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.справочникиToolStripMenuItem,
            this.документыToolStripMenuItem,
            this.отчетыToolStripMenuItem,
            this.оПрограммеToolStripMenuItem,
            this.выходToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(422, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // справочникиToolStripMenuItem
            // 
            this.справочникиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.физическиеЛицаToolStripMenuItem,
            this.toolStripMenuItem1,
            this.подразделенияToolStripMenuItem,
            this.должностиToolStripMenuItem,
            this.toolStripMenuItem2,
            this.пользователиToolStripMenuItem,
            this.toolStripMenuItem3,
            this.контрагентыToolStripMenuItem});
            this.справочникиToolStripMenuItem.Name = "справочникиToolStripMenuItem";
            this.справочникиToolStripMenuItem.Size = new System.Drawing.Size(94, 20);
            this.справочникиToolStripMenuItem.Text = "Справочники";
            // 
            // физическиеЛицаToolStripMenuItem
            // 
            this.физическиеЛицаToolStripMenuItem.Name = "физическиеЛицаToolStripMenuItem";
            this.физическиеЛицаToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.физическиеЛицаToolStripMenuItem.Text = "Физические лица";
            this.физическиеЛицаToolStripMenuItem.Click += new System.EventHandler(this.физическиеЛицаToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(168, 6);
            // 
            // подразделенияToolStripMenuItem
            // 
            this.подразделенияToolStripMenuItem.Name = "подразделенияToolStripMenuItem";
            this.подразделенияToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.подразделенияToolStripMenuItem.Text = "Подразделения";
            this.подразделенияToolStripMenuItem.Click += new System.EventHandler(this.подразделенияToolStripMenuItem_Click);
            // 
            // должностиToolStripMenuItem
            // 
            this.должностиToolStripMenuItem.Name = "должностиToolStripMenuItem";
            this.должностиToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.должностиToolStripMenuItem.Text = "Должности";
            this.должностиToolStripMenuItem.Click += new System.EventHandler(this.должностиToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(168, 6);
            // 
            // пользователиToolStripMenuItem
            // 
            this.пользователиToolStripMenuItem.Name = "пользователиToolStripMenuItem";
            this.пользователиToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.пользователиToolStripMenuItem.Text = "Пользователи";
            this.пользователиToolStripMenuItem.Click += new System.EventHandler(this.пользователиToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(168, 6);
            // 
            // контрагентыToolStripMenuItem
            // 
            this.контрагентыToolStripMenuItem.Name = "контрагентыToolStripMenuItem";
            this.контрагентыToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.контрагентыToolStripMenuItem.Text = "Контрагенты";
            this.контрагентыToolStripMenuItem.Click += new System.EventHandler(this.контрагентыToolStripMenuItem_Click);
            // 
            // документыToolStripMenuItem
            // 
            this.документыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.календарныеПланыToolStripMenuItem,
            this.проектыToolStripMenuItem,
            this.постановкаЗадачToolStripMenuItem,
            this.исполнениеЗадачToolStripMenuItem});
            this.документыToolStripMenuItem.Name = "документыToolStripMenuItem";
            this.документыToolStripMenuItem.Size = new System.Drawing.Size(82, 20);
            this.документыToolStripMenuItem.Text = "Документы";
            // 
            // календарныеПланыToolStripMenuItem
            // 
            this.календарныеПланыToolStripMenuItem.Name = "календарныеПланыToolStripMenuItem";
            this.календарныеПланыToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.календарныеПланыToolStripMenuItem.Text = "Календарные планы";
            this.календарныеПланыToolStripMenuItem.Click += new System.EventHandler(this.календарныеПланыToolStripMenuItem_Click);
            // 
            // проектыToolStripMenuItem
            // 
            this.проектыToolStripMenuItem.Name = "проектыToolStripMenuItem";
            this.проектыToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.проектыToolStripMenuItem.Text = "Проекты";
            this.проектыToolStripMenuItem.Click += new System.EventHandler(this.проектыToolStripMenuItem_Click);
            // 
            // постановкаЗадачToolStripMenuItem
            // 
            this.постановкаЗадачToolStripMenuItem.Name = "постановкаЗадачToolStripMenuItem";
            this.постановкаЗадачToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.постановкаЗадачToolStripMenuItem.Text = "Постановка задач";
            this.постановкаЗадачToolStripMenuItem.Click += new System.EventHandler(this.постановкаЗадачToolStripMenuItem_Click);
            // 
            // исполнениеЗадачToolStripMenuItem
            // 
            this.исполнениеЗадачToolStripMenuItem.Name = "исполнениеЗадачToolStripMenuItem";
            this.исполнениеЗадачToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.исполнениеЗадачToolStripMenuItem.Text = "Исполнение задач";
            this.исполнениеЗадачToolStripMenuItem.Click += new System.EventHandler(this.исполнениеЗадачToolStripMenuItem_Click);
            // 
            // отчетыToolStripMenuItem
            // 
            this.отчетыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.сводныйКалендарныйПланToolStripMenuItem,
            this.анализВыполненияЗадачпланфактToolStripMenuItem});
            this.отчетыToolStripMenuItem.Name = "отчетыToolStripMenuItem";
            this.отчетыToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.отчетыToolStripMenuItem.Text = "Отчеты";
            // 
            // сводныйКалендарныйПланToolStripMenuItem
            // 
            this.сводныйКалендарныйПланToolStripMenuItem.Name = "сводныйКалендарныйПланToolStripMenuItem";
            this.сводныйКалендарныйПланToolStripMenuItem.Size = new System.Drawing.Size(288, 22);
            this.сводныйКалендарныйПланToolStripMenuItem.Text = "Сводный календарный план";
            this.сводныйКалендарныйПланToolStripMenuItem.Click += new System.EventHandler(this.сводныйКалендарныйПланToolStripMenuItem_Click);
            // 
            // анализВыполненияЗадачпланфактToolStripMenuItem
            // 
            this.анализВыполненияЗадачпланфактToolStripMenuItem.Name = "анализВыполненияЗадачпланфактToolStripMenuItem";
            this.анализВыполненияЗадачпланфактToolStripMenuItem.Size = new System.Drawing.Size(288, 22);
            this.анализВыполненияЗадачпланфактToolStripMenuItem.Text = "Анализ выполнения задач (план/факт)";
            this.анализВыполненияЗадачпланфактToolStripMenuItem.Click += new System.EventHandler(this.анализВыполненияЗадачпланфактToolStripMenuItem_Click);
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(92, 20);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.оПрограммеToolStripMenuItem_Click);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.выходToolStripMenuItem_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Products_Button);
            this.groupBox1.Controls.Add(this.Departments_Button);
            this.groupBox1.Controls.Add(this.Partners_Button);
            this.groupBox1.Controls.Add(this.Positions_Button);
            this.groupBox1.Controls.Add(this.Individuals_Button);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.groupBox1.Location = new System.Drawing.Point(12, 45);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(401, 137);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Справочники";
            // 
            // Products_Button
            // 
            this.Products_Button.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Products_Button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Products_Button.Location = new System.Drawing.Point(201, 60);
            this.Products_Button.Name = "Products_Button";
            this.Products_Button.Size = new System.Drawing.Size(189, 29);
            this.Products_Button.TabIndex = 4;
            this.Products_Button.Text = "Пользователи";
            this.Products_Button.UseVisualStyleBackColor = true;
            this.Products_Button.Click += new System.EventHandler(this.пользователиToolStripMenuItem_Click);
            // 
            // Departments_Button
            // 
            this.Departments_Button.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Departments_Button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Departments_Button.Location = new System.Drawing.Point(201, 25);
            this.Departments_Button.Name = "Departments_Button";
            this.Departments_Button.Size = new System.Drawing.Size(189, 29);
            this.Departments_Button.TabIndex = 3;
            this.Departments_Button.Text = "Подразделения";
            this.Departments_Button.UseVisualStyleBackColor = true;
            this.Departments_Button.Click += new System.EventHandler(this.подразделенияToolStripMenuItem_Click);
            // 
            // Partners_Button
            // 
            this.Partners_Button.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Partners_Button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Partners_Button.Location = new System.Drawing.Point(6, 95);
            this.Partners_Button.Name = "Partners_Button";
            this.Partners_Button.Size = new System.Drawing.Size(384, 29);
            this.Partners_Button.TabIndex = 2;
            this.Partners_Button.Text = "Контрагенты предприятия";
            this.Partners_Button.UseVisualStyleBackColor = true;
            this.Partners_Button.Click += new System.EventHandler(this.контрагентыToolStripMenuItem_Click);
            // 
            // Positions_Button
            // 
            this.Positions_Button.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Positions_Button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Positions_Button.Location = new System.Drawing.Point(6, 60);
            this.Positions_Button.Name = "Positions_Button";
            this.Positions_Button.Size = new System.Drawing.Size(189, 29);
            this.Positions_Button.TabIndex = 1;
            this.Positions_Button.Text = "Должности";
            this.Positions_Button.UseVisualStyleBackColor = true;
            this.Positions_Button.Click += new System.EventHandler(this.должностиToolStripMenuItem_Click);
            // 
            // Individuals_Button
            // 
            this.Individuals_Button.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Individuals_Button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Individuals_Button.Location = new System.Drawing.Point(6, 25);
            this.Individuals_Button.Name = "Individuals_Button";
            this.Individuals_Button.Size = new System.Drawing.Size(189, 29);
            this.Individuals_Button.TabIndex = 0;
            this.Individuals_Button.Text = "Физические лица";
            this.Individuals_Button.UseVisualStyleBackColor = true;
            this.Individuals_Button.Click += new System.EventHandler(this.физическиеЛицаToolStripMenuItem_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ExecutionTasks_Button);
            this.groupBox2.Controls.Add(this.SettingTasks_Button);
            this.groupBox2.Controls.Add(this.Projects_Button);
            this.groupBox2.Controls.Add(this.CalendarProjects_Button);
            this.groupBox2.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.groupBox2.Location = new System.Drawing.Point(12, 188);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(401, 167);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Документы";
            // 
            // ExecutionTasks_Button
            // 
            this.ExecutionTasks_Button.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ExecutionTasks_Button.ForeColor = System.Drawing.Color.Purple;
            this.ExecutionTasks_Button.Location = new System.Drawing.Point(6, 130);
            this.ExecutionTasks_Button.Name = "ExecutionTasks_Button";
            this.ExecutionTasks_Button.Size = new System.Drawing.Size(384, 29);
            this.ExecutionTasks_Button.TabIndex = 3;
            this.ExecutionTasks_Button.Text = "Исполнение задач";
            this.ExecutionTasks_Button.UseVisualStyleBackColor = true;
            this.ExecutionTasks_Button.Click += new System.EventHandler(this.исполнениеЗадачToolStripMenuItem_Click);
            // 
            // SettingTasks_Button
            // 
            this.SettingTasks_Button.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SettingTasks_Button.ForeColor = System.Drawing.Color.Purple;
            this.SettingTasks_Button.Location = new System.Drawing.Point(6, 95);
            this.SettingTasks_Button.Name = "SettingTasks_Button";
            this.SettingTasks_Button.Size = new System.Drawing.Size(384, 29);
            this.SettingTasks_Button.TabIndex = 2;
            this.SettingTasks_Button.Text = "Постановка задач";
            this.SettingTasks_Button.UseVisualStyleBackColor = true;
            this.SettingTasks_Button.Click += new System.EventHandler(this.постановкаЗадачToolStripMenuItem_Click);
            // 
            // Projects_Button
            // 
            this.Projects_Button.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Projects_Button.ForeColor = System.Drawing.Color.Purple;
            this.Projects_Button.Location = new System.Drawing.Point(6, 60);
            this.Projects_Button.Name = "Projects_Button";
            this.Projects_Button.Size = new System.Drawing.Size(384, 29);
            this.Projects_Button.TabIndex = 1;
            this.Projects_Button.Text = "Проекты";
            this.Projects_Button.UseVisualStyleBackColor = true;
            this.Projects_Button.Click += new System.EventHandler(this.проектыToolStripMenuItem_Click);
            // 
            // CalendarProjects_Button
            // 
            this.CalendarProjects_Button.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CalendarProjects_Button.ForeColor = System.Drawing.Color.Purple;
            this.CalendarProjects_Button.Location = new System.Drawing.Point(6, 25);
            this.CalendarProjects_Button.Name = "CalendarProjects_Button";
            this.CalendarProjects_Button.Size = new System.Drawing.Size(384, 29);
            this.CalendarProjects_Button.TabIndex = 0;
            this.CalendarProjects_Button.Text = "Календарные планы";
            this.CalendarProjects_Button.UseVisualStyleBackColor = true;
            this.CalendarProjects_Button.Click += new System.EventHandler(this.календарныеПланыToolStripMenuItem_Click);
            // 
            // Exit_Button
            // 
            this.Exit_Button.Font = new System.Drawing.Font("Arial", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Exit_Button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.Exit_Button.Location = new System.Drawing.Point(12, 361);
            this.Exit_Button.Name = "Exit_Button";
            this.Exit_Button.Size = new System.Drawing.Size(401, 45);
            this.Exit_Button.TabIndex = 5;
            this.Exit_Button.Text = "Выход";
            this.Exit_Button.UseVisualStyleBackColor = true;
            this.Exit_Button.Click += new System.EventHandler(this.выходToolStripMenuItem_Click);
            // 
            // Form_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(422, 410);
            this.Controls.Add(this.Exit_Button);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Form_Main";
            this.RightToLeftLayout = true;
            this.Text = "Система электронного документооборота АО \"НБИ\"";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form_Main_FormClosed);
            this.Load += new System.EventHandler(this.Form_Main_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem справочникиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem документыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отчетыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem физическиеЛицаToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem подразделенияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem должностиToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem пользователиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem календарныеПланыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem проектыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem постановкаЗадачToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem исполнениеЗадачToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem контрагентыToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button Products_Button;
        private System.Windows.Forms.Button Departments_Button;
        private System.Windows.Forms.Button Partners_Button;
        private System.Windows.Forms.Button Positions_Button;
        private System.Windows.Forms.Button Individuals_Button;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button ExecutionTasks_Button;
        private System.Windows.Forms.Button SettingTasks_Button;
        private System.Windows.Forms.Button Projects_Button;
        private System.Windows.Forms.Button CalendarProjects_Button;
        private System.Windows.Forms.Button Exit_Button;
        private System.Windows.Forms.ToolStripMenuItem сводныйКалендарныйПланToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem анализВыполненияЗадачпланфактToolStripMenuItem;
    }
}